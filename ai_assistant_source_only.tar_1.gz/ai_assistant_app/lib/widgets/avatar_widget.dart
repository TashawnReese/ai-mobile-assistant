import 'package:flutter/material.dart';
import '../providers/avatar_provider.dart';

class AvatarWidget extends StatelessWidget {
  final AvatarConfig config;
  final double size;

  const AvatarWidget({
    super.key,
    required this.config,
    this.size = 40,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: config.skinTone,
        border: Border.all(
          color: Theme.of(context).colorScheme.outline,
          width: 2,
        ),
      ),
      child: Stack(
        children: [
          // Face
          Center(
            child: Container(
              width: size * 0.8,
              height: size * 0.8,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: config.skinTone,
              ),
            ),
          ),
          
          // Hair
          Positioned(
            top: size * 0.1,
            left: size * 0.2,
            right: size * 0.2,
            child: Container(
              height: size * 0.3,
              decoration: BoxDecoration(
                color: config.hairColor,
                borderRadius: BorderRadius.circular(size * 0.3),
              ),
            ),
          ),
          
          // Eyes
          Positioned(
            top: size * 0.35,
            left: size * 0.25,
            child: Container(
              width: size * 0.1,
              height: size * 0.1,
              decoration: BoxDecoration(
                color: config.eyeColor,
                shape: BoxShape.circle,
              ),
            ),
          ),
          Positioned(
            top: size * 0.35,
            right: size * 0.25,
            child: Container(
              width: size * 0.1,
              height: size * 0.1,
              decoration: BoxDecoration(
                color: config.eyeColor,
                shape: BoxShape.circle,
              ),
            ),
          ),
          
          // Clothing indicator
          Positioned(
            bottom: 0,
            left: size * 0.2,
            right: size * 0.2,
            child: Container(
              height: size * 0.2,
              decoration: BoxDecoration(
                color: config.clothingColor,
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(size * 0.3),
                  bottomRight: Radius.circular(size * 0.3),
                ),
              ),
            ),
          ),
          
          // Accessory
          if (config.accessory == 'glasses')
            Positioned(
              top: size * 0.3,
              left: size * 0.15,
              right: size * 0.15,
              child: Container(
                height: size * 0.15,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black, width: 1),
                  borderRadius: BorderRadius.circular(size * 0.1),
                ),
              ),
            ),
          
          if (config.accessory == 'hat')
            Positioned(
              top: 0,
              left: size * 0.1,
              right: size * 0.1,
              child: Container(
                height: size * 0.2,
                decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.circular(size * 0.1),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

