import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state_provider.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final TextEditingController _apiKeyController = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final appState = context.read<AppStateProvider>();
      _apiKeyController.text = appState.apiKey;
    });
  }

  @override
  void dispose() {
    _apiKeyController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
      ),
      body: Consumer<AppStateProvider>(
        builder: (context, appState, child) {
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              // API Configuration
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'API Configuration',
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      const SizedBox(height: 16),
                      TextField(
                        controller: _apiKeyController,
                        decoration: const InputDecoration(
                          labelText: 'OpenAI API Key',
                          hintText: 'sk-...',
                          border: OutlineInputBorder(),
                          helperText: 'Required for full AI functionality',
                        ),
                        obscureText: true,
                        onChanged: (value) {
                          appState.setApiKey(value);
                        },
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Get your API key from: https://platform.openai.com/',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
              ),
              
              const SizedBox(height: 16),
              
              // Appearance
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Appearance',
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      const SizedBox(height: 16),
                      SwitchListTile(
                        title: const Text('Dark Mode'),
                        subtitle: const Text('Use dark theme'),
                        value: appState.isDarkMode,
                        onChanged: (value) {
                          appState.toggleDarkMode();
                        },
                      ),
                    ],
                  ),
                ),
              ),
              
              const SizedBox(height: 16),
              
              // Language
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Language',
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      const SizedBox(height: 16),
                      DropdownButtonFormField<String>(
                        value: appState.selectedLanguage,
                        decoration: const InputDecoration(
                          labelText: 'Interface Language',
                          border: OutlineInputBorder(),
                        ),
                        items: const [
                          DropdownMenuItem(value: 'en', child: Text('English')),
                          DropdownMenuItem(value: 'es', child: Text('Español')),
                          DropdownMenuItem(value: 'fr', child: Text('Français')),
                          DropdownMenuItem(value: 'de', child: Text('Deutsch')),
                          DropdownMenuItem(value: 'it', child: Text('Italiano')),
                          DropdownMenuItem(value: 'pt', child: Text('Português')),
                          DropdownMenuItem(value: 'zh', child: Text('中文')),
                        ],
                        onChanged: (value) {
                          if (value != null) {
                            appState.setLanguage(value);
                          }
                        },
                      ),
                    ],
                  ),
                ),
              ),
              
              const SizedBox(height: 16),
              
              // Voice Settings
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Voice Settings',
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      const SizedBox(height: 16),
                      ListTile(
                        title: const Text('Voice Recognition'),
                        subtitle: const Text('Enable voice input'),
                        trailing: Switch(
                          value: true,
                          onChanged: (value) {
                            // Handle voice recognition toggle
                          },
                        ),
                      ),
                      ListTile(
                        title: const Text('Text-to-Speech'),
                        subtitle: const Text('Enable voice output'),
                        trailing: Switch(
                          value: true,
                          onChanged: (value) {
                            // Handle TTS toggle
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              
              const SizedBox(height: 16),
              
              // Data Management
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Data Management',
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      const SizedBox(height: 16),
                      ListTile(
                        title: const Text('Clear Chat History'),
                        subtitle: const Text('Remove all conversation data'),
                        trailing: const Icon(Icons.delete),
                        onTap: () {
                          _showClearDataDialog(context);
                        },
                      ),
                      ListTile(
                        title: const Text('Clear Uploaded Files'),
                        subtitle: const Text('Remove all file data'),
                        trailing: const Icon(Icons.delete),
                        onTap: () {
                          _showClearDataDialog(context);
                        },
                      ),
                    ],
                  ),
                ),
              ),
              
              const SizedBox(height: 16),
              
              // About
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'About',
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      const SizedBox(height: 16),
                      ListTile(
                        title: const Text('Version'),
                        subtitle: const Text('1.0.0'),
                        trailing: const Icon(Icons.info),
                      ),
                      ListTile(
                        title: const Text('Privacy Policy'),
                        subtitle: const Text('View privacy policy'),
                        trailing: const Icon(Icons.privacy_tip),
                        onTap: () {
                          _showPrivacyPolicy(context);
                        },
                      ),
                      ListTile(
                        title: const Text('Help & Support'),
                        subtitle: const Text('Get help using the app'),
                        trailing: const Icon(Icons.help),
                        onTap: () {
                          _showHelpDialog(context);
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  void _showClearDataDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Clear Data'),
        content: const Text('Are you sure you want to clear this data? This action cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Data cleared successfully')),
              );
            },
            child: const Text('Clear'),
          ),
        ],
      ),
    );
  }

  void _showPrivacyPolicy(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Privacy Policy'),
        content: const SingleChildScrollView(
          child: Text(
            'AI Assistant Privacy Policy\n\n'
            '1. Data Collection: We only store data locally on your device.\n\n'
            '2. API Usage: Your API key is stored securely and only used for AI requests.\n\n'
            '3. File Processing: Uploaded files are processed locally and not transmitted unless you explicitly use AI analysis features.\n\n'
            '4. Voice Data: Voice recordings are processed for speech recognition and not stored permanently.\n\n'
            '5. No Tracking: We do not track your usage or collect personal information.\n\n'
            'For questions, contact support.',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  void _showHelpDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Help & Support'),
        content: const SingleChildScrollView(
          child: Text(
            'AI Assistant Help\n\n'
            '🤖 Chat: Talk with the AI assistant using text or voice\n\n'
            '📁 Files: Upload files for AI analysis (PDF, images, audio, video, code)\n\n'
            '👤 Avatar: Customize your AI assistant\'s appearance\n\n'
            '⚙️ Settings: Configure API key, language, and preferences\n\n'
            '🎤 Voice: Tap the microphone to use voice input\n\n'
            '🔑 API Key: Get your OpenAI API key from platform.openai.com\n\n'
            'Need more help? Check the documentation or contact support.',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }
}

