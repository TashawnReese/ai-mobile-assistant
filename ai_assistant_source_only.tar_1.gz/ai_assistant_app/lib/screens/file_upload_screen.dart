import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:provider/provider.dart';
import '../providers/chat_provider.dart';
import 'dart:io';

class FileUploadScreen extends StatefulWidget {
  const FileUploadScreen({super.key});

  @override
  State<FileUploadScreen> createState() => _FileUploadScreenState();
}

class _FileUploadScreenState extends State<FileUploadScreen> {
  List<PlatformFile> _uploadedFiles = [];
  bool _isProcessing = false;

  Future<void> _pickFiles() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        allowMultiple: true,
        type: FileType.any,
      );

      if (result != null) {
        setState(() {
          _uploadedFiles.addAll(result.files);
        });
        
        // Simulate file analysis
        _analyzeFiles(result.files);
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error picking files: $e')),
      );
    }
  }

  Future<void> _analyzeFiles(List<PlatformFile> files) async {
    setState(() {
      _isProcessing = true;
    });

    for (var file in files) {
      await Future.delayed(const Duration(seconds: 1));
      
      String analysis = _generateFileAnalysis(file);
      
      if (mounted) {
        context.read<ChatProvider>().addSystemMessage(
          'File Analysis: ${file.name}\n\n$analysis'
        );
      }
    }

    setState(() {
      _isProcessing = false;
    });
  }

  String _generateFileAnalysis(PlatformFile file) {
    String extension = file.extension?.toLowerCase() ?? '';
    String size = _formatFileSize(file.size);
    
    String analysis = 'File: ${file.name}\nSize: $size\nType: ${extension.toUpperCase()}\n\n';
    
    switch (extension) {
      case 'pdf':
        analysis += 'This is a PDF document. I can extract text content, analyze structure, and provide summaries. The document appears to contain ${(file.size / 1000).round()} KB of data.';
        break;
      case 'jpg':
      case 'jpeg':
      case 'png':
      case 'gif':
        analysis += 'This is an image file. I can analyze visual content, extract text (OCR), identify objects, and describe the image composition.';
        break;
      case 'mp3':
      case 'wav':
      case 'aac':
        analysis += 'This is an audio file. I can transcribe speech, analyze audio patterns, and extract metadata information.';
        break;
      case 'mp4':
      case 'avi':
      case 'mov':
        analysis += 'This is a video file. I can extract frames, transcribe audio, and analyze video content and structure.';
        break;
      case 'txt':
      case 'md':
        analysis += 'This is a text document. I can analyze content, extract key information, summarize, and perform text processing tasks.';
        break;
      case 'dart':
      case 'java':
      case 'py':
      case 'js':
      case 'html':
      case 'css':
        analysis += 'This is a code file. I can analyze code structure, suggest improvements, identify patterns, and help with debugging.';
        break;
      case 'apk':
        analysis += 'This is an Android APK file. I can analyze app structure, extract metadata, and provide insights about the application (for educational purposes only).';
        break;
      default:
        analysis += 'This file type is supported. I can analyze its structure and provide relevant insights based on the content.';
    }
    
    return analysis;
  }

  String _formatFileSize(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    if (bytes < 1024 * 1024 * 1024) return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
  }

  IconData _getFileIcon(String? extension) {
    switch (extension?.toLowerCase()) {
      case 'pdf':
        return Icons.picture_as_pdf;
      case 'jpg':
      case 'jpeg':
      case 'png':
      case 'gif':
        return Icons.image;
      case 'mp3':
      case 'wav':
      case 'aac':
        return Icons.audiotrack;
      case 'mp4':
      case 'avi':
      case 'mov':
        return Icons.video_file;
      case 'txt':
      case 'md':
        return Icons.text_snippet;
      case 'dart':
      case 'java':
      case 'py':
      case 'js':
      case 'html':
      case 'css':
        return Icons.code;
      case 'apk':
        return Icons.android;
      default:
        return Icons.insert_drive_file;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('File Upload & Analysis'),
        actions: [
          if (_uploadedFiles.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.clear_all),
              onPressed: () {
                setState(() {
                  _uploadedFiles.clear();
                });
              },
              tooltip: 'Clear All Files',
            ),
        ],
      ),
      body: Column(
        children: [
          // Upload Area
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(32),
            decoration: BoxDecoration(
              border: Border.all(
                color: Theme.of(context).colorScheme.outline,
                style: BorderStyle.solid,
                width: 2,
              ),
              borderRadius: BorderRadius.circular(12),
              color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.3),
            ),
            child: Column(
              children: [
                Icon(
                  Icons.cloud_upload,
                  size: 64,
                  color: Theme.of(context).colorScheme.primary,
                ),
                const SizedBox(height: 16),
                Text(
                  'Upload Files for AI Analysis',
                  style: Theme.of(context).textTheme.headlineSmall,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 8),
                Text(
                  'Supports: PDF, Images, Audio, Video, Code, APK, and more',
                  style: Theme.of(context).textTheme.bodyMedium,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 24),
                ElevatedButton.icon(
                  onPressed: _isProcessing ? null : _pickFiles,
                  icon: const Icon(Icons.upload_file),
                  label: const Text('Choose Files'),
                ),
              ],
            ),
          ),
          
          // Processing Indicator
          if (_isProcessing)
            const Padding(
              padding: EdgeInsets.all(16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(width: 16),
                  Text('Analyzing files...'),
                ],
              ),
            ),
          
          // Uploaded Files List
          Expanded(
            child: _uploadedFiles.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.folder_open,
                          size: 64,
                          color: Theme.of(context).colorScheme.outline,
                        ),
                        const SizedBox(height: 16),
                        Text(
                          'No files uploaded yet',
                          style: Theme.of(context).textTheme.bodyLarge,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Upload files to see AI analysis results',
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: _uploadedFiles.length,
                    itemBuilder: (context, index) {
                      final file = _uploadedFiles[index];
                      return Card(
                        margin: const EdgeInsets.only(bottom: 8),
                        child: ListTile(
                          leading: Icon(
                            _getFileIcon(file.extension),
                            size: 32,
                            color: Theme.of(context).colorScheme.primary,
                          ),
                          title: Text(
                            file.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          subtitle: Text(
                            '${file.extension?.toUpperCase() ?? 'Unknown'} • ${_formatFileSize(file.size)}',
                          ),
                          trailing: IconButton(
                            icon: const Icon(Icons.delete),
                            onPressed: () {
                              setState(() {
                                _uploadedFiles.removeAt(index);
                              });
                            },
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

