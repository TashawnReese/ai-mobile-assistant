import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/avatar_provider.dart';
import '../widgets/avatar_widget.dart';

class AvatarCustomizationScreen extends StatelessWidget {
  const AvatarCustomizationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Customize Avatar'),
        actions: [
          IconButton(
            icon: const Icon(Icons.shuffle),
            onPressed: () {
              context.read<AvatarProvider>().randomizeAvatar();
            },
            tooltip: 'Random Avatar',
          ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              context.read<AvatarProvider>().resetToDefault();
            },
            tooltip: 'Reset to Default',
          ),
        ],
      ),
      body: Consumer<AvatarProvider>(
        builder: (context, avatarProvider, child) {
          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                // Avatar Preview
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      children: [
                        const Text(
                          'Preview',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 16),
                        AvatarWidget(
                          config: avatarProvider.config,
                          size: 120,
                        ),
                      ],
                    ),
                  ),
                ),
                
                const SizedBox(height: 24),
                
                // Hair Style
                _buildOptionSection(
                  'Hair Style',
                  ['short', 'long', 'curly', 'straight'],
                  avatarProvider.config.hairStyle,
                  (style) => avatarProvider.updateHairStyle(style),
                ),
                
                // Hair Color
                _buildColorSection(
                  'Hair Color',
                  [Colors.brown, Colors.black, const Color(0xFFFFC107), Colors.red],
                  avatarProvider.config.hairColor,
                  (color) => avatarProvider.updateHairColor(color),
                ),
                
                // Skin Tone
                _buildColorSection(
                  'Skin Tone',
                  [
                    const Color(0xFFDEB887),
                    const Color(0xFFF5DEB3),
                    const Color(0xFFD2B48C),
                    const Color(0xFF8B4513),
                  ],
                  avatarProvider.config.skinTone,
                  (color) => avatarProvider.updateSkinTone(color),
                ),
                
                // Eye Color
                _buildColorSection(
                  'Eye Color',
                  [Colors.blue, Colors.green, Colors.brown, Colors.grey],
                  avatarProvider.config.eyeColor,
                  (color) => avatarProvider.updateEyeColor(color),
                ),
                
                // Clothing
                _buildOptionSection(
                  'Clothing',
                  ['shirt', 'jacket', 'dress', 'hoodie'],
                  avatarProvider.config.clothing,
                  (clothing) => avatarProvider.updateClothing(clothing),
                ),
                
                // Clothing Color
                _buildColorSection(
                  'Clothing Color',
                  [Colors.blue, Colors.red, Colors.green, Colors.purple],
                  avatarProvider.config.clothingColor,
                  (color) => avatarProvider.updateClothingColor(color),
                ),
                
                // Accessories
                _buildOptionSection(
                  'Accessories',
                  ['none', 'glasses', 'hat', 'earrings'],
                  avatarProvider.config.accessory,
                  (accessory) => avatarProvider.updateAccessory(accessory),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildOptionSection(
    String title,
    List<String> options,
    String currentValue,
    Function(String) onChanged,
  ) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              children: options.map((option) {
                return ChoiceChip(
                  label: Text(option.toUpperCase()),
                  selected: currentValue == option,
                  onSelected: (selected) {
                    if (selected) onChanged(option);
                  },
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildColorSection(
    String title,
    List<Color> colors,
    Color currentColor,
    Function(Color) onChanged,
  ) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              children: colors.map((color) {
                return GestureDetector(
                  onTap: () => onChanged(color),
                  child: Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: color,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: currentColor == color ? Colors.black : Colors.grey,
                        width: currentColor == color ? 3 : 1,
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }
}

