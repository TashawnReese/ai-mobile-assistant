import 'package:flutter/material.dart';
import 'dart:math' as math;

class ChatMessage {
  final String content;
  final bool isUser;
  final DateTime timestamp;
  
  ChatMessage({
    required this.content,
    required this.isUser,
    required this.timestamp,
  });
}

class ChatProvider extends ChangeNotifier {
  final List<ChatMessage> _messages = [];
  bool _isTyping = false;
  bool _isListening = false;
  
  List<ChatMessage> get messages => _messages;
  bool get isTyping => _isTyping;
  bool get isListening => _isListening;
  
  void addUserMessage(String content) {
    _messages.add(ChatMessage(
      content: content,
      isUser: true,
      timestamp: DateTime.now(),
    ));
    notifyListeners();
    
    // Simulate AI response
    _simulateAIResponse(content);
  }
  
  Future<void> _simulateAIResponse(String userMessage) async {
    _isTyping = true;
    notifyListeners();
    
    // Simulate thinking time
    await Future.delayed(const Duration(seconds: 2));
    
    String response = _generateResponse(userMessage);
    
    _messages.add(ChatMessage(
      content: response,
      isUser: false,
      timestamp: DateTime.now(),
    ));
    
    _isTyping = false;
    notifyListeners();
  }
  
  String _generateResponse(String userMessage) {
    final responses = [
      "I'm your AI assistant! I can help you with voice commands, file analysis, and much more. Add your OpenAI API key in settings for full functionality.",
      "That's interesting! I can process various file types including PDFs, images, audio, and video files. Try uploading a file to see what I can do!",
      "I'm here to help! You can customize my avatar, use voice commands, or ask me to analyze files. What would you like to explore?",
      "Great question! I can help with app development, file processing, voice recognition, and much more. My capabilities expand when you add your API key.",
      "I love helping with AI projects! I can analyze code, process documents, and assist with development tasks. What are you working on?",
    ];
    
    return responses[math.Random().nextInt(responses.length)];
  }
  
  void setListening(bool listening) {
    _isListening = listening;
    notifyListeners();
  }
  
  void clearChat() {
    _messages.clear();
    notifyListeners();
  }
  
  void addSystemMessage(String content) {
    _messages.add(ChatMessage(
      content: content,
      isUser: false,
      timestamp: DateTime.now(),
    ));
    notifyListeners();
  }
}

