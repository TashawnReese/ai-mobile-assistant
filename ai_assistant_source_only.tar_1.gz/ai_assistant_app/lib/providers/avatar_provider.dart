import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'dart:math' as math;

class AvatarConfig {
  String hairStyle;
  Color hairColor;
  Color skinTone;
  Color eyeColor;
  String clothing;
  Color clothingColor;
  String accessory;
  
  AvatarConfig({
    this.hairStyle = 'short',
    this.hairColor = Colors.brown,
    this.skinTone = const Color(0xFFDEB887),
    this.eyeColor = Colors.blue,
    this.clothing = 'shirt',
    this.clothingColor = Colors.blue,
    this.accessory = 'none',
  });
  
  Map<String, dynamic> toJson() => {
    'hairStyle': hairStyle,
    'hairColor': hairColor.value,
    'skinTone': skinTone.value,
    'eyeColor': eyeColor.value,
    'clothing': clothing,
    'clothingColor': clothingColor.value,
    'accessory': accessory,
  };
  
  factory AvatarConfig.fromJson(Map<String, dynamic> json) => AvatarConfig(
    hairStyle: json['hairStyle'] ?? 'short',
    hairColor: Color(json['hairColor'] ?? Colors.brown.value),
    skinTone: Color(json['skinTone'] ?? const Color(0xFFDEB887).value),
    eyeColor: Color(json['eyeColor'] ?? Colors.blue.value),
    clothing: json['clothing'] ?? 'shirt',
    clothingColor: Color(json['clothingColor'] ?? Colors.blue.value),
    accessory: json['accessory'] ?? 'none',
  );
}

class AvatarProvider extends ChangeNotifier {
  AvatarConfig _config = AvatarConfig();
  
  AvatarConfig get config => _config;
  
  AvatarProvider() {
    _loadAvatar();
  }
  
  Future<void> _loadAvatar() async {
    final prefs = await SharedPreferences.getInstance();
    final avatarJson = prefs.getString('avatar_config');
    if (avatarJson != null) {
      _config = AvatarConfig.fromJson(jsonDecode(avatarJson));
      notifyListeners();
    }
  }
  
  Future<void> _saveAvatar() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('avatar_config', jsonEncode(_config.toJson()));
  }
  
  void updateHairStyle(String style) {
    _config.hairStyle = style;
    _saveAvatar();
    notifyListeners();
  }
  
  void updateHairColor(Color color) {
    _config.hairColor = color;
    _saveAvatar();
    notifyListeners();
  }
  
  void updateSkinTone(Color color) {
    _config.skinTone = color;
    _saveAvatar();
    notifyListeners();
  }
  
  void updateEyeColor(Color color) {
    _config.eyeColor = color;
    _saveAvatar();
    notifyListeners();
  }
  
  void updateClothing(String clothing) {
    _config.clothing = clothing;
    _saveAvatar();
    notifyListeners();
  }
  
  void updateClothingColor(Color color) {
    _config.clothingColor = color;
    _saveAvatar();
    notifyListeners();
  }
  
  void updateAccessory(String accessory) {
    _config.accessory = accessory;
    _saveAvatar();
    notifyListeners();
  }
  
  void randomizeAvatar() {
    final hairStyles = ['short', 'long', 'curly', 'straight'];
    final hairColors = [Colors.brown, Colors.black, const Color(0xFFFFC107), Colors.red];
    final skinTones = [
      const Color(0xFFDEB887),
      const Color(0xFFF5DEB3),
      const Color(0xFFD2B48C),
      const Color(0xFF8B4513),
    ];
    final eyeColors = [Colors.blue, Colors.green, Colors.brown, Colors.grey];
    final clothingOptions = ['shirt', 'jacket', 'dress', 'hoodie'];
    final clothingColors = [Colors.blue, Colors.red, Colors.green, Colors.purple];
    final accessories = ['none', 'glasses', 'hat', 'earrings'];
    
    final random = math.Random();
    
    _config = AvatarConfig(
      hairStyle: hairStyles[random.nextInt(hairStyles.length)],
      hairColor: hairColors[random.nextInt(hairColors.length)],
      skinTone: skinTones[random.nextInt(skinTones.length)],
      eyeColor: eyeColors[random.nextInt(eyeColors.length)],
      clothing: clothingOptions[random.nextInt(clothingOptions.length)],
      clothingColor: clothingColors[random.nextInt(clothingColors.length)],
      accessory: accessories[random.nextInt(accessories.length)],
    );
    
    _saveAvatar();
    notifyListeners();
  }
  
  void resetToDefault() {
    _config = AvatarConfig();
    _saveAvatar();
    notifyListeners();
  }
}

